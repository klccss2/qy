<?php
session_start();

header("Content-type: image/png");
##生成验证码图片
$str = "2,3,4,5,6,7,8,9,a,b,c,d,e,f,g,h,i,j,k,m,n,p,q,r,s,t,u,v,w,x,y,z";      
##要显示的字符，可自己进行增删

$list = explode(",", $str);
$cmax = count($list) - 1;
$verifyCode = '';
for ( $i=0; $i < 4; $i++ ){
	$randnum = mt_rand(0, $cmax);
	$verifyCode .= $list[$randnum];           	     
	##取出字符，组合成为我们要的验证码字符
}
$_SESSION['verifycode'] = $verifyCode;        
##将字符放入SESSION中
$im = imagecreatetruecolor(100,40);     
// 定义要用到的颜色     
$back_color = imagecolorallocate($im, 235, 236, 237);     
$boer_color = imagecolorallocate($im, 118, 151, 199);     
$text_color = imagecolorallocate($im, mt_rand(0,200), mt_rand(0,120), mt_rand(0,120));     

// 画背景     
imagefilledrectangle($im,0,0,100,40,$back_color);     
// 画边框     
imagerectangle($im,0,0,99,39,$boer_color);     
// 画干扰线     
for($i=0;$i<5;$i++){     
    $font_color = imagecolorallocate($im, mt_rand(0,255), mt_rand(0,255), mt_rand(0,255));     
    imagearc($im,mt_rand(-100,100),mt_rand(-40,40),mt_rand(30,200),mt_rand(20,80),mt_rand(0,360),mt_rand(0,360),$font_color);     
}     
// 画干扰点     
for($i=0;$i<50;$i++){     
$font_color = imagecolorallocate($im, mt_rand(0,255), mt_rand(0,255), mt_rand(0,255));     
imagesetpixel($im,mt_rand(0,$width),mt_rand(0,$height),$font_color);     
}     
@imagefttext($im, 20 , 0, 10, 30, $text_color, '../assets/fonts/ariali.ttf',$verifyCode);   
##加入点状干扰象素
imagepng($im);
imagedestroy($im);
?>